"""
[Python] 関数（def）学習用スクリプト

このファイルの使い方：
- 章ごとの解説＋サンプルコードを「小さな関数（demo_XXX）」にまとめています
- 実行すると簡単なメニューが出るので、番号を選んで動きを確認できます
- 自分の練習用コードは「practice_XXX」関数の中に書いていくと整理しやすいです

学習のポイント：
- 教材を読むだけでなく、「このファイルを実行しながらコードを少しずつ変更する」こと
- 動きを変えてみる／printを増やしてみる／自分なりの例を追加してみる、など
"""

# ============================================================
# 1. 関数とは何か（イメージ）
# ============================================================

def demo_1_no_function():
    """関数を使わずに同じ処理を何度も書いている例"""
    print("=== demo_1_no_function: 関数なしで同じ処理を3回書く ===")
    price1 = 1000
    tax_rate = 0.1
    total1 = int(price1 * (1 + tax_rate))

    price2 = 2500
    tax_rate = 0.1
    total2 = int(price2 * (1 + tax_rate))

    price3 = 300
    tax_rate = 0.1
    total3 = int(price3 * (1 + tax_rate))

    print("total1:", total1)
    print("total2:", total2)
    print("total3:", total3)


def calc_total(price, tax_rate):
    """教材で出てきた calc_total 関数"""
    total = int(price * (1 + tax_rate))
    return total


def demo_1_with_function():
    """同じ処理を関数にまとめてスッキリさせた例"""
    print("=== demo_1_with_function: 関数を使ってスッキリ ===")
    total1 = calc_total(1000, 0.1)
    total2 = calc_total(2500, 0.1)
    total3 = calc_total(300, 0.1)

    print("total1:", total1)
    print("total2:", total2)
    print("total3:", total3)


# ============================================================
# 2. 関数の基本構文（def と 呼び出し）
# ============================================================

def say_hello():
    """一番シンプルな関数の例"""
    print("こんにちは！")


def demo_2_basic_function():
    print("=== demo_2_basic_function: 関数の定義と呼び出し ===")
    say_hello()  # 1回目
    say_hello()  # 2回目


# ============================================================
# 3. 引数と戻り値（return）
# ============================================================

def greet(name):
    """引数を1つ受け取る関数"""
    print("こんにちは、" + name + "さん")


def add(a, b):
    """2つの数値を足して戻り値として返す関数"""
    result = a + b
    return result


def add_print(a, b):
    """計算結果をprintするだけの関数"""
    print(a + b)


def add_return(a, b):
    """計算結果を戻り値として返す関数"""
    return a + b


def test_return():
    print("ここまでは実行される")
    return
    # ここには絶対来ない
    print("ここは実行されない")


def demo_3_args_and_return():
    print("=== demo_3_args_and_return: 引数と戻り値 ===")
    # 引数の例
    greet("山田")
    greet("田中")

    # 戻り値の例
    x = add(3, 5)
    print("add(3, 5) の結果:", x)

    # print と return の違い
    print("\n--- add_print と add_return の違い ---")
    xp = add_print(3, 5)  # 画面には表示されるが xp は None になる
    print("add_print の戻り値 xp:", xp)

    xr = add_return(3, 5)
    print("add_return の戻り値 xr:", xr)

    print("\n--- return で関数が終了する例 ---")
    test_return()


# ============================================================
# 4. いろいろな引数の使い方
# ============================================================

def introduce(name, age):
    print(f"私は{name}です。{age}歳です。")


def greet_default(name="ゲスト"):
    print(f"こんにちは、{name}さん")


def calc_total_with_default(price, tax_rate=0.1):
    return int(price * (1 + tax_rate))


def introduce_with_country(name, age, country):
    print(f"私は{name}です。{country}出身で、{age}歳です。")


def demo_4_various_args():
    print("=== demo_4_various_args: 複数引数・デフォルト引数・キーワード引数 ===")

    print("\n--- 複数の引数 ---")
    introduce("山田", 20)

    print("\n--- デフォルト引数 ---")
    greet_default()
    greet_default("田中")

    print("\n--- デフォルト引数（Django に近い例）---")
    print(calc_total_with_default(1000))         # デフォルト 0.1
    print(calc_total_with_default(1000, 0.08))   # 引数で上書き

    print("\n--- キーワード引数 ---")
    introduce_with_country("山田", 20, "日本")
    introduce_with_country(age=30, name="李", country="中国")  # 順番を入れ替えてもOK


# ============================================================
# 5. 戻り値を複数返す
# ============================================================

def calc_stats(scores):
    """合計と平均を同時に返す例"""
    total = sum(scores)
    count = len(scores)
    average = total / count
    return total, average


def demo_5_multi_return():
    print("=== demo_5_multi_return: 戻り値を複数返す ===")
    scores = [80, 90, 70]
    total, avg = calc_stats(scores)
    print("scores:", scores)
    print("合計:", total)
    print("平均:", avg)


# ============================================================
# 6. ローカル変数とグローバル変数
# ============================================================

def sample_local():
    x = 10  # ローカル変数
    print("sample_local の中の x:", x)


tax_rate_global = 0.1  # グローバル変数の例


def calc_total_with_global(price):
    # global tax_rate_global  ← ここでは「読み込み」だけなので global は不要
    return int(price * (1 + tax_rate_global))


def demo_6_scope():
    print("=== demo_6_scope: ローカル変数とグローバル変数 ===")

    print("\n--- ローカル変数 ---")
    sample_local()
    print("sample_local の外から x にアクセスするとエラーになるのでコメントアウト")
    # print(x)  # ← 実際に試すとエラーになる（NameError）

    print("\n--- グローバル変数 ---")
    print("tax_rate_global:", tax_rate_global)
    print("calc_total_with_global(1000):", calc_total_with_global(1000))


# ============================================================
# 7. Django との関係：関数ベースビュー風の例
# ============================================================

def fake_render(request, template_name, context):
    """本物の Django render ではなく、動きをイメージするためのダミー"""
    print("=== fake_render ===")
    print("request:", request)
    print("template_name:", template_name)
    print("context:", context)
    # 本物の Django では、ここで HttpResponse を返す


def item_list_view(request):
    """
    Django の関数ベースビューをイメージした関数。
    実際の Django では from django.shortcuts import render を使う。
    """
    items = [
        {"name": "ノート", "price": 100},
        {"name": "えんぴつ", "price": 50},
    ]
    context = {"items": items}
    # return render(request, "item_list.html", context)
    # 今回は fake_render で代用
    return fake_render(request, "item_list.html", context)


def demo_7_django_like_view():
    print("=== demo_7_django_like_view: Django 風 関数ベースビュー ===")
    # 本物の Django では request は HttpRequest だが、
    # ここでは単なる文字列で代用してイメージだけ掴む
    dummy_request = "ダミーリクエスト"
    item_list_view(dummy_request)


# ============================================================
# 8. 練習問題用の関数（自分で実装）
# ============================================================

def practice_calc_total_price():
    """
    練習1:
    税込み金額を計算する関数 calc_total_price(price, tax_rate=0.1) を作ってみよう。

    仕様:
    - 引数 price: 税抜価格（int）
    - 引数 tax_rate: 税率（float, デフォルト 0.1）
    - 戻り値: 税込み価格（小数点以下は切り捨てて int にする）

    ヒント:
    - price * (1 + tax_rate)
    - int(...) で整数にする

    とりあえず「pass」を消して、自分のコードを書いてみてください。
    """
    pass  # ← ここを消して、関数本体を書いてみる


def practice_make_item_message():
    """
    練習2:
    商品名と価格からメッセージを作る関数 make_item_message(name, price) を作る。

    仕様:
    - 引数 name: 商品名（str）
    - 引数 price: 価格（int）
    - 戻り値: "商品名: XXX / 価格: YYY 円" という文字列

    例:
    make_item_message("ノートPC", 150000)
    -> "商品名: ノートPC / 価格: 150000 円"
    """
    pass  # ここを自分のコードに置き換える


def demo_practice_examples():
    """
    練習問題を自分で実装したあと、ここで動作確認してみてください。
    """
    print("=== demo_practice_examples ===")
    # 例（自分で実装できたらコメントアウトを外して試す）:

    # total = practice_calc_total_price()
    # print("税込み価格:", total)

    # msg = practice_make_item_message()
    # print("メッセージ:", msg)

    print("※ まずは practice_XXX 関数の中身を書いてから、この関数を使ってテストしてみてください。")


# ============================================================
# メニュー＆メイン処理
# ============================================================

def main_menu():
    while True:
        print("\n==============================")
        print("[Python] 関数（def）デモメニュー")
        print("1: 関数のイメージ（関数なし／あり）")
        print("2: 基本の関数定義と呼び出し")
        print("3: 引数と戻り値（print と return の違い）")
        print("4: いろいろな引数（デフォルト・キーワード引数）")
        print("5: 戻り値を複数返す")
        print("6: ローカル変数とグローバル変数")
        print("7: Django 風 関数ベースビューのイメージ")
        print("8: 練習問題のテスト用デモ")
        print("0: 終了")
        print("==============================")
        choice = input("番号を選んでください: ")

        if choice == "1":
            demo_1_no_function()
            print()
            demo_1_with_function()
        elif choice == "2":
            demo_2_basic_function()
        elif choice == "3":
            demo_3_args_and_return()
        elif choice == "4":
            demo_4_various_args()
        elif choice == "5":
            demo_5_multi_return()
        elif choice == "6":
            demo_6_scope()
        elif choice == "7":
            demo_7_django_like_view()
        elif choice == "8":
            demo_practice_examples()
        elif choice == "0":
            print("終了します。")
            break
        else:
            print("0〜8の数字を入力してください。")


if __name__ == "__main__":
    main_menu()
