"""
[Python] 例外処理（try / except）学習用スクリプト

このファイルの使い方：
- 教材に出てきたコードを、小さなデモ関数（demo_XXX）に分けてあります。
- 実行するとメニューが出るので、番号を選んで動きを確認できます。
- 自分の練習用コードは「practice_XXX」関数の中に書いていくと整理しやすいです。

学習スタイルのおすすめ：
- 学习的时候不要只抄代码段落，而是：
  给每一章准备一个「练习用 .py 文件」，把示例代码包装成可以直接运行的小函数 / 小demo，
  边看边写，边改边跑。
"""

# ============================================================
# 1. 例外（エラー）とは何か
# ============================================================

def demo_1_exception_concept():
    """
    ZeroDivisionError / ValueError がどんな感じで出るのかを、
    try/except で安全に見てみるデモ。
    """
    print("=== demo_1_exception_concept: 例外とは何か ===")

    print("\n--- 0 で割った場合（ZeroDivisionError の例）---")
    try:
        x = 10 / 0
        print("結果:", x)
    except ZeroDivisionError as e:
        print("ZeroDivisionError が発生しました:", e)

    print("\n--- 数字でない文字列を int に変換する場合（ValueError の例）---")
    try:
        y = int("abc")
        print("変換結果:", y)
    except ValueError as e:
        print("ValueError が発生しました:", e)

    print("\n※ 実際のコードでは try/except がないと、ここでプログラムが止まってしまいます。")


# ============================================================
# 2. try / except の基本
# ============================================================

def demo_2_basic_try_except():
    """
    一番シンプルな try / except の例。
    """
    print("=== demo_2_basic_try_except: 基本の try / except ===")
    try:
        print("10 / 0 を計算してみます...")
        x = 10 / 0
        print("ここには来ない:", x)
    except ZeroDivisionError:
        print("0 で割ることはできません（ZeroDivisionError）")


def demo_3_user_input_value_error():
    """
    ユーザー入力 → int() 変換 → ValueError を処理する例。
    """
    print("=== demo_3_user_input_value_error: ユーザー入力 + ValueError ===")
    user_input = input("数字を入力してください: ")

    try:
        value = int(user_input)
        print("2倍の値は", value * 2, "です。")
    except ValueError:
        print("数字を入力してください（例: 10）")


# ============================================================
# 3. 複数の例外を処理する
# ============================================================

def demo_4_multiple_excepts():
    """
    ValueError と ZeroDivisionError を分けて処理する例。
    """
    print("=== demo_4_multiple_excepts: 複数の例外を個別に処理 ===")
    user_input = input("数字を入力してください（0 を入れると 0 で割るテスト）: ")

    try:
        value = int(user_input)
        result = 10 / value
        print("10 / 入力値 =", result)
    except ValueError:
        print("数字に変換できませんでした（ValueError）。")
    except ZeroDivisionError:
        print("0 で割ることはできません（ZeroDivisionError）。")


def demo_5_catch_many_or_all():
    """
    タプルでまとめて捕まえる / Exception ですべて捕まえる例。
    """
    print("=== demo_5_catch_many_or_all: まとめて捕まえる ===")

    print("\n--- (ValueError, ZeroDivisionError) をまとめて捕まえる例 ---")
    user_input = input("数字を入力してください（ValueError / ZeroDivisionError テスト）: ")

    try:
        value = int(user_input)
        result = 10 / value
        print("10 / 入力値 =", result)
    except (ValueError, ZeroDivisionError):
        print("入力に問題があります（ValueError または ZeroDivisionError）。")

    print("\n--- Exception ですべての例外をまとめて捕まえる例 ---")
    try:
        # わざとエラーになりそうな処理を書いてみる
        x = int("abc")  # ValueError
    except Exception as e:
        print("何かしらのエラーが発生しました（Exception で捕捉）:", e)


# ============================================================
# 4. エラー情報を as e で受け取る
# ============================================================

def demo_6_as_e():
    """
    except ValueError as e: の形でエラー情報を受け取る例。
    """
    print("=== demo_6_as_e: エラー情報を as e で受け取る ===")
    try:
        x = int("abc")
    except ValueError as e:
        print("エラー内容:", e)
        print("type(e):", type(e))


# ============================================================
# 5. else と finally
# ============================================================

def demo_7_else_and_finally():
    """
    try/except/else/finally の流れをまとめて見るデモ。
    """
    print("=== demo_7_else_and_finally: else / finally ===")

    print("\n--- else: エラーがなかったときだけ実行 ---")
    try:
        x = int(input("数字を入力してください（else の例）: "))
    except ValueError:
        print("数字に変換できませんでした（ValueError）。")
    else:
        print("2倍の値は", x * 2, "です。")

    print("\n--- finally: エラーがあってもなくても必ず実行 ---")
    try:
        print("存在しないかもしれないファイル 'data.txt' を開こうとします。")
        f = open("data.txt", "r", encoding="utf-8")
        content = f.read()
        print("ファイル内容:")
        print(content)
        f.close()
    except FileNotFoundError:
        print("ファイルが見つかりませんでした（FileNotFoundError）。")
    finally:
        print("（finally）処理を終了します。ファイルのクローズや後片付けに使います。")


# ============================================================
# 6. 自分で例外を発生させる（raise）
# ============================================================

def divide(a, b):
    """教材に出てきた divide 関数のイメージ。"""
    if b == 0:
        # 自分で例外を発生させる
        raise ValueError("0 で割ることはできません")
    return a / b


def demo_8_raise():
    """
    raise で自分から例外を投げて、それを try/except で受け取る例。
    """
    print("=== demo_8_raise: 自分で例外を発生させる（raise） ===")

    try:
        a = float(input("a を入力してください: "))
        b = float(input("b を入力してください（0 を入れるとエラー）: "))
        result = divide(a, b)
    except ValueError as e:
        print("エラー:", e)
    else:
        print("a / b =", result)


# ============================================================
# 7. よくある例外 & よくない書き方
# ============================================================

def demo_9_common_exceptions_and_bad_pattern():
    """
    よくある例外の種類を軽く体験する + よくない except: の例。
    """
    print("=== demo_9_common_exceptions_and_bad_pattern ===")

    print("\n--- よくある例外を安全に試してみる ---")

    # ZeroDivisionError
    try:
        _ = 1 / 0
    except ZeroDivisionError as e:
        print("ZeroDivisionError:", e)

    # TypeError
    try:
        _ = "a" + 1
    except TypeError as e:
        print("TypeError:", e)

    # IndexError
    try:
        lst = [1, 2, 3]
        _ = lst[10]
    except IndexError as e:
        print("IndexError:", e)

    # KeyError
    try:
        d = {"name": "山田"}
        _ = d["age"]
    except KeyError as e:
        print("KeyError:", e)

    # FileNotFoundError
    try:
        open("no_such_file_123.txt", "r", encoding="utf-8")
    except FileNotFoundError as e:
        print("FileNotFoundError:", e)

    print("\n--- よくない書き方の例（真似しないでOK）---")
    print("※ 実際には実行せず、コードだけ紹介します。")
    print("""
# よくない例（何が起きたか分からなくなる）
try:
    処理
except:
    pass  # ← 何もせず黙殺
""")


# ============================================================
# 8. 練習問題用の関数（自分で実装するスペース）
# ============================================================

def practice_1_safe_divide():
    """
    練習1:
    safe_divide(a, b) を作ってみよう。

    仕様：
    - a, b を引数に受け取る
    - b が 0 の場合：
        - 「0 で割ることはできません」と表示
        - None を返す
    - それ以外の場合：
        - a / b の結果を返す

    ヒント：
    - try/except を使う方法
    - または b == 0 のときに自分でチェックしてメッセージを出す方法
    """
    print("=== practice_1_safe_divide ===")
    # TODO: ここに自分のコードを書いてみる
    # 例：
    # def safe_divide(a, b):
    #     try:
    #         return a / b
    #     except ZeroDivisionError:
    #         print("0 で割ることはできません")
    #         return None
    #
    # a = float(input("a: "))
    # b = float(input("b: "))
    # result = safe_divide(a, b)
    # print("結果:", result)
    pass  # 書けたらこの pass を削除


def practice_2_input_and_int():
    """
    練習2:
    ユーザーからの入力を int に変換する処理を、try/except/else を使って書いてみよう。

    仕様：
    1. input() で文字列を受け取る
    2. int() で整数に変換する
    3. 変換に成功したら、その2倍を表示（else の中で）
    4. ValueError が出た場合は
       「数字を入力してください」と表示

    ヒント：
    - demo_3_user_input_value_error
    - demo_7_else_and_finally
    を参考にすると書きやすいです。
    """
    print("=== practice_2_input_and_int ===")
    # TODO: ここに自分のコードを書いてみる
    pass  # 書けたらこの pass を削除


def practice_3_dict_access():
    """
    練習3:
    辞書アクセスの安全版関数 get_user_info(user, key) を作ってみよう。

    仕様：
    - 引数 user: 辞書（例: {"name": "山田", "age": 20}）
    - 引数 key: 取り出したいキー（文字列）
    - 挙動：
        - user[key] が存在すればその値を返す
        - 存在しなければ KeyError を捕まえ、
          「キー xxx は存在しません」と表示して None を返す

    ヒント：
    - try:
    -     value = user[key]
    - except KeyError:
    -     メッセージ表示
    -     return None
    """
    print("=== practice_3_dict_access ===")
    # TODO: ここに自分のコードを書いてみる
    pass  # 書けたらこの pass を削除


def demo_practice_area():
    """
    上の practice_XXX 関数を試すためのエリア。
    まず practice_XXX の中身を書いてから、ここで呼び出してテストします。
    """
    print("=== demo_practice_area ===")
    print("※ まずは practice_XXX 関数の中身を書いてから、ここで呼び出してみてください。")

    # 書けたものだけコメントアウトを外して試してください。
    # practice_1_safe_divide()
    # practice_2_input_and_int()
    # practice_3_dict_access()


# ============================================================
# メニュー & メイン処理
# ============================================================

def main_menu():
    while True:
        print("\n==============================")
        print("[Python] 例外処理（try / except）デモメニュー")
        print("1: 例外とは何か（ZeroDivisionError / ValueError）")
        print("2: 基本の try / except（0 で割る）")
        print("3: ユーザー入力 + ValueError の処理")
        print("4: 複数の例外を個別に処理する")
        print("5: まとめて捕まえる / Exception で全部捕まえる")
        print("6: as e でエラー情報を受け取る")
        print("7: else / finally の動き")
        print("8: raise で自分で例外を発生させる")
        print("9: よくある例外 & よくない書き方の例")
        print("P: 練習問題エリア（practice_XXX を試す）")
        print("0: 終了")
        print("==============================")
        choice = input("番号を選んでください: ")

        if choice == "1":
            demo_1_exception_concept()
        elif choice == "2":
            demo_2_basic_try_except()
        elif choice == "3":
            demo_3_user_input_value_error()
        elif choice == "4":
            demo_4_multiple_excepts()
        elif choice == "5":
            demo_5_catch_many_or_all()
        elif choice == "6":
            demo_6_as_e()
        elif choice == "7":
            demo_7_else_and_finally()
        elif choice == "8":
            demo_8_raise()
        elif choice == "9":
            demo_9_common_exceptions_and_bad_pattern()
        elif choice.upper() == "P":
            demo_practice_area()
        elif choice == "0":
            print("終了します。")
            break
        else:
            print("0〜9 または P を入力してください。")


if __name__ == "__main__":
    main_menu()
