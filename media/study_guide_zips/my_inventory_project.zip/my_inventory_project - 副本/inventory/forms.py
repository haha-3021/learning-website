from django import forms
from .models import Item, Category

class ItemForm(forms.___1___):
    # ___1___ ヒント: モデルからフォームを自動生成してくれる Django のクラス

    class Meta:
        model = ___2___
        # ___2___ ヒント: このフォームが対応するモデル（物品を表すモデル）

        fields = ['name', 'category', 'price', 'purchase_date', 'description']
        # ヒント: フォームで入力させたいフィールド名のリスト

        widgets = {
            'name': forms.___3___(attrs={'class': 'form-control'}),
            # ___3___ ヒント: 1行テキスト入力用のウィジェット

            'category': forms.___4___(attrs={'class': 'form-control'}),
            # ___4___ ヒント: プルダウン（選択リスト）用のウィジェット

            'price': forms.___5___(attrs={'class': 'form-control'}),
            # ___5___ ヒント: 数値入力用のウィジェット

            'purchase_date': forms.___6___(attrs={'class': 'form-control', 'type': 'date'}),
            # ___6___ ヒント: 日付入力用のウィジェット（HTML の date 型を使う）

            'description': forms.___7___(attrs={'class': 'form-control', 'rows': 3}),
            # ___7___ ヒント: 複数行テキスト入力用のウィジェット
        }

        labels = {
            'name': '物品名',
            'category': 'カテゴリー',
            'price': '価格（円）',
            'purchase_date': '購入日',
            'description': '説明',
        }
        # ヒント: フォームのラベル（画面に表示される日本語名）


class CategoryForm(forms.___1___):
    # ヒント: カテゴリ用フォームでも同じ ModelForm を継承する

    class Meta:
        model = ___8___
        # ___8___ ヒント: このフォームが対応するモデル（カテゴリーを表すモデル）

        fields = ['name', 'description']

        widgets = {
            'name': forms.___3___(attrs={'class': 'form-control'}),
            # ヒント: カテゴリー名も1行テキスト入力

            'description': forms.___7___(attrs={'class': 'form-control', 'rows': 3}),
            # ヒント: カテゴリーの説明は複数行テキスト
        }

        labels = {
            'name': 'カテゴリー名',
            'description': '説明',
        }
