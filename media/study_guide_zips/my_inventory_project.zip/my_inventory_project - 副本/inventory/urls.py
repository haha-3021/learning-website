# inventory/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # アイテム一覧（トップページ）
    path('', views.ItemListView.as_view(), name='item_list'),

    # アイテム追加
    path('items/new/', views.ItemCreateView.as_view(), name='item_create'),

    # アイテム編集
    path('items/<int:pk>/edit/', views.ItemUpdateView.as_view(), name='item_update'),

    # アイテム削除
    path('items/<int:pk>/delete/', views.ItemDeleteView.as_view(), name='item_delete'),
]
