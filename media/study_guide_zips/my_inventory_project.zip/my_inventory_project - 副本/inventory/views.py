from django.shortcuts import render, get_object_or_404, redirect
from django.urls import ___1___  # ヒント: 遅延評価できる URL 逆引き関数（CBVの success_url でよく使う）
from django.views.generic import ___2___, ___3___, ___4___, ___5___
# ___2___ ヒント: 一覧表示用の汎用クラスビュー
# ___3___ ヒント: 新規作成用の汎用クラスビュー
# ___4___ ヒント: 更新（編集）用の汎用クラスビュー
# ___5___ ヒント: 削除用の汎用クラスビュー

from .models import Item
from .forms import ItemForm


class ItemListView(___2___):
    """アイテムの一覧と、総価格・総日割り価格を表示するビュー"""
    model = ___6___        # ヒント: 一覧表示の対象となるモデル
    template_name = 'inventory/item_list.html'
    context_object_name = '___7___'
    # ___7___ ヒント: テンプレート側で一覧データを参照するときの変数名

    def get_context_data(self, **kwargs):
        """
        一覧表示用のコンテキストに、
        総価格（total_price）と総日割り価格（total_daily_price）を追加します。
        """
        context = super().___8___(**kwargs)
        # ___8___ ヒント: 親クラスのコンテキスト取得メソッドを呼び出す

        items = context['___7___']

        # 総価格：すべてのアイテムの price の合計
        total_price_raw = ___9___(item.price for item in items)
        # ___9___ ヒント: イテラブルの合計を求める Python 組み込み関数

        # 総日割り価格：すべてのアイテムの daily_price の合計
        total_daily_price_raw = ___9___(item.daily_price for item in items)

        # 表示用に整形した文字列としてコンテキストに追加
        context['total_price'] = f'¥{total_price_raw:,}'
        context['total_daily_price'] = f'¥{total_daily_price_raw:,}'

        return context


class ItemCreateView(___3___):
    model = Item
    form_class = ___10___           # ヒント: このビューで使うフォームクラス
    template_name = 'inventory/item_form.html'
    success_url = ___1___('item_list')
    # ヒント: 登録成功後に一覧ページへリダイレクトするための URL


class ItemUpdateView(___4___):
    model = Item
    form_class = ___10___
    template_name = 'inventory/item_form.html'
    success_url = ___1___('item_list')


class ItemDeleteView(___5___):
    model = Item
    template_name = 'inventory/item_confirm_delete.html'
    success_url = ___1___('item_list')
