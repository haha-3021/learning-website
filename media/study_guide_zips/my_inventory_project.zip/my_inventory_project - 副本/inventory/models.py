from django.db import models
from django.urls import ___1___  # ヒント: URL名からURLを生成する関数（urls.py でもよく使う）
from django.utils import ___2___  # ヒント: 現在日時などを扱う Django のユーティリティモジュール

class Category(models.Model):
    name = models.___3___(max_length=___4___, verbose_name='カテゴリー名')
    # ___3___ ヒント: 文字列（短いテキスト）を保存するフィールド
    # ___4___ ヒント: カテゴリー名の最大文字数（例: 100）

    description = models.___5___(blank=___6___, verbose_name='説明')
    # ___5___ ヒント: 長めの文章を保存するフィールド
    # ___6___ ヒント: 入力が空でもよいときに True にするオプション

    created_at = models.___7___(___8___=True, verbose_name='作成日時')
    # ___7___ ヒント: 日付と時刻を保存するフィールド
    # ___8___ ヒント: 「作成時に一度だけ自動で現在時刻を入れる」ための引数

    class Meta:
        verbose_name = 'カテゴリー'
        verbose_name_plural = 'カテゴリー'

    def __str__(self):
        return self.___9___
        # ___9___ ヒント: 管理画面などで、このオブジェクトを文字列として表示するときに使いたいフィールド名

    def get_absolute_url(self):
        return ___1___('category_list')


class Item(models.Model):
    name = models.___3___(max_length=___10___, verbose_name='物品名')
    # ___10___ ヒント: 物品名の最大文字数（例: 200）

    category = models.___11___(
        Category,
        on_delete=models.___12___,
        verbose_name='カテゴリー'
    )
    # ___11___ ヒント: 別のモデル（Category）を参照する外部キー
    # ___12___ ヒント: 参照先が削除されたとき、一緒に削除されるようにするオプション

    price = models.___13___(verbose_name='価格（円）')
    # ___13___ ヒント: 整数（小数なし）を保存するフィールド

    purchase_date = models.___14___(verbose_name='購入日')
    # ___14___ ヒント: 年月日だけを扱う日付フィールド

    description = models.___5___(blank=___6___, verbose_name='説明')
    created_at = models.___7___(___8___=True, verbose_name='作成日時')

    class Meta:
        verbose_name = '物品'
        verbose_name_plural = '物品'

    def __str__(self):
        return self.___9___

    def get_absolute_url(self):
        return ___1___('item_list')

    @property
    def formatted_price(self):
        return f'¥{self.___15___:,}'
        # ___15___ ヒント: 価格（円）を表すフィールド名

    @property
    def days_since_purchase(self):
        """購入日からの経過日数を計算"""
        today = ___2___.___16___().___17___()
        # ___16___ ヒント: 「今この瞬間の日時」を取得する関数
        # ___17___ ヒント: 日付部分だけ（date型）を取り出すメソッド

        days = (today - self.___18___).days
        # ___18___ ヒント: 購入日を表すフィールド名

        return ___19___(days, 1)  # 最低1日とする
        # ___19___ ヒント: 2つの値のうち、大きい方を返す Python 組み込み関数

    @property
    def daily_depreciation(self):
        """日次減価償却を自動計算"""
        if self.days_since_purchase > 0:
            return self.___15___ // self.___20___
            # ___20___ ヒント: 経過日数を返す、このクラス内のプロパティ名
        return 0

    @property
    def formatted_daily_depreciation(self):
        return f'¥{self.___21___:,}'
        # ___21___ ヒント: 日次減価償却の結果を表すプロパティ名
