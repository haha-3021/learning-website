from django.contrib import admin
from .models import Category, Item

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'purchase_date', 'days_since_purchase', 'daily_depreciation']
    list_filter = ['category', 'purchase_date']
    search_fields = ['name']
    date_hierarchy = 'purchase_date'
    
    def days_since_purchase(self, obj):
        return f"{obj.days_since_purchase}日"
    days_since_purchase.short_description = '経過日数'
    
    def daily_depreciation(self, obj):
        return f"¥{obj.daily_depreciation:,}"
    daily_depreciation.short_description = '日次減価償却'
